# Shadowrocket---iOS-ipa
Shadowrocket，一款要垮区域购买，或者通过国内第三方平台才能安装的VPN软件，但是我们iOS开发者几乎只会用mac，现在Itunes又限制了应用ipa包的安装，但是没有了Itunes，我们有xcode！！


博客地址： http://blog.cocoachina.com/article/95453
